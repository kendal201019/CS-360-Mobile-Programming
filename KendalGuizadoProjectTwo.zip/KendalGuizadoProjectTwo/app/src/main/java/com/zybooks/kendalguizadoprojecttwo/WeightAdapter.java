package com.zybooks.kendalguizadoprojecttwo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private List<WeightEntry> weightList;
    private WeightDatabaseHelper weightDbHelper; // Add this line

    public WeightAdapter(List<WeightEntry> weightList, WeightDatabaseHelper weightDbHelper) {
        this.weightList = weightList;
        this.weightDbHelper = weightDbHelper; // Add this line
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry weightEntry = weightList.get(position);

        holder.weightTextView.setText("Weight: " + weightEntry.getWeightValue());
        holder.dateTextView.setText("Date: " + weightEntry.getDate());

        holder.deleteButton.setOnClickListener(v -> {
            // Handle delete button click
            int deletedPosition = holder.getAdapterPosition();
            deleteWeightEntry(deletedPosition);
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView;
        TextView dateTextView;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    private void deleteWeightEntry(int position) {
        // Retrieve the weight entry to be deleted
        WeightEntry weightEntry = weightList.get(position);

        // Delete the weight entry from the database
        long result = weightDbHelper.deleteWeightEntry(weightEntry.getId());

        if (result != -1) {
            // Update the displayed weight list
            weightList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, weightList.size());
        }
    }

    public void updateList(List<WeightEntry> updatedWeightList) {
        this.weightList = updatedWeightList;
        notifyDataSetChanged();
    }
}


