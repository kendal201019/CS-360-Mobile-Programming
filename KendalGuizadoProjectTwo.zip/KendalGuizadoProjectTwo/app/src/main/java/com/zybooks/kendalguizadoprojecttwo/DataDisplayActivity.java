package com.zybooks.kendalguizadoprojecttwo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private Button setGoalButton, addWeightButton;
    private RecyclerView weightsRecyclerView;
    private List<WeightEntry> weightList;
    private WeightAdapter weightAdapter;
    private WeightDatabaseHelper weightDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        setGoalButton = findViewById(R.id.setGoalButton);
        addWeightButton = findViewById(R.id.addWeightButton);
        weightsRecyclerView = findViewById(R.id.weightsRecyclerView);

        weightDbHelper = new WeightDatabaseHelper(this);

        // Populate weightList from the database
        weightList = weightDbHelper.getAllWeights();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        weightsRecyclerView.setLayoutManager(layoutManager);

        weightAdapter = new WeightAdapter(weightList, weightDbHelper);

        weightsRecyclerView.setAdapter(weightAdapter);

        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve weight and date from user input
                EditText weightInputEditText = findViewById(R.id.weightInput);
                EditText dateInputEditText = findViewById(R.id.dateInput);

                // Get user input values
                String weightInput = weightInputEditText.getText().toString();
                String dateInput = dateInputEditText.getText().toString();

                // Check if input is not empty
                if (!weightInput.isEmpty() && !dateInput.isEmpty()) {
                    // Convert weightInput to double
                    double weightValue = Double.parseDouble(weightInput);

                    // Add the weight entry to the database
                    long result = weightDbHelper.addWeightEntry(weightValue, dateInput);

                    if (result != -1) {
                        // Update the displayed weight list
                        List<WeightEntry> updatedWeightList = weightDbHelper.getAllWeights();
                        weightAdapter.updateList(updatedWeightList);
                        weightAdapter.notifyDataSetChanged();

                        // Clear the input fields
                        weightInputEditText.getText().clear();
                        dateInputEditText.getText().clear();

                        Toast.makeText(DataDisplayActivity.this, "Weight added successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(DataDisplayActivity.this, "Failed to add weight entry", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(DataDisplayActivity.this, "Please enter weight and date", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

