package com.zybooks.kendalguizadoprojecttwo;


public class WeightEntry {

    private int id;
    private double weightValue;
    private String date;

    public WeightEntry(int id, double weightValue, String date) {
        this.id = id;
        this.weightValue = weightValue;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public double getWeightValue() {
        return weightValue;
    }

    public String getDate() {
        return date;
    }
}

