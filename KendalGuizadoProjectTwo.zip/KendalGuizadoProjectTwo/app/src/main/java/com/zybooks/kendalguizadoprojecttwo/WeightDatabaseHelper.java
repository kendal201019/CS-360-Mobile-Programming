package com.zybooks.kendalguizadoprojecttwo;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class WeightDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table and columns for weight entries
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_WEIGHT_ID = "id";
    private static final String COLUMN_WEIGHT_VALUE = "weight_value";
    private static final String COLUMN_DATE = "date";

    // Create table query
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                    COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_WEIGHT_VALUE + " REAL, " +
                    COLUMN_DATE + " TEXT);";

    public WeightDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // Method to add a new weight entry to the database
    public long addWeightEntry(double weightValue, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_VALUE, weightValue);
        values.put(COLUMN_DATE, date);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        db.close();
        return result;
    }

    // Method to get all weight entries from the database
    public List<WeightEntry> getAllWeights() {
        List<WeightEntry> weightList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_WEIGHTS + " ORDER BY " + COLUMN_DATE + " DESC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(COLUMN_WEIGHT_ID));
                @SuppressLint("Range") double weightValue = cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT_VALUE));
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));

                WeightEntry weightEntry = new WeightEntry(id, weightValue, date);
                weightList.add(weightEntry);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return weightList;
    }

    // Method to delete a weight entry from the database
    public long deleteWeightEntry(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define the WHERE clause
        String selection = COLUMN_WEIGHT_ID + " = ?";
        String[] selectionArgs = {String.valueOf(weightId)};

        // Delete the row
        return db.delete(TABLE_WEIGHTS, selection, selectionArgs);
    }


    // Method to update a weight entry in the database
    public int updateWeightEntry(int weightId, double newWeightValue, String newDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_VALUE, newWeightValue);
        values.put(COLUMN_DATE, newDate);

        int rowsAffected = db.update(TABLE_WEIGHTS, values, COLUMN_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(weightId)});

        db.close();
        return rowsAffected;
    }


}
