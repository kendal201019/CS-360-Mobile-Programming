package com.zybooks.kendalguizadoprojecttwo;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);

        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.new_account_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createAccount();
            }
        });
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NAME,
                null,
                DatabaseHelper.COLUMN_USERNAME + " = ? AND " +
                        DatabaseHelper.COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        if (cursor != null && cursor.getCount() > 0) {
            // Successful login
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class );
            startActivity(intent);
            finish();
        } else {
            // Failed login
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }

        if (cursor != null) {
            cursor.close();
        }
        db.close();
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Check if the username already exists
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NAME,
                null,
                DatabaseHelper.COLUMN_USERNAME + " = ?",
                new String[]{username},
                null,
                null,
                null
        );

        if (cursor != null && cursor.getCount() > 0) {
            // Username already exists
            Toast.makeText(this, "Username already exists. Choose a different one.", Toast.LENGTH_SHORT).show();
        } else {
            // Insert new account
            db.execSQL("INSERT INTO " + DatabaseHelper.TABLE_NAME +
                    " (" + DatabaseHelper.COLUMN_USERNAME + ", " + DatabaseHelper.COLUMN_PASSWORD + ") " +
                    "VALUES ('" + username + "', '" + password + "')");

            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
        }

        if (cursor != null) {
            cursor.close();
        }
        db.close();
    }
}