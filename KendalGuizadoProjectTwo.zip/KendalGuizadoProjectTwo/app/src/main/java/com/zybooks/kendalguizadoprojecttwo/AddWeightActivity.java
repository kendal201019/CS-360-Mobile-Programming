package com.zybooks.kendalguizadoprojecttwo;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {

    private EditText weightValueEditText;
    private Button saveButton;
    private WeightDatabaseHelper weightDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        weightValueEditText = findViewById(R.id.weightValueEditText);
        saveButton = findViewById(R.id.saveButton);
        weightDbHelper = new WeightDatabaseHelper(this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveWeight();
            }
        });
    }

    private void saveWeight() {
        // Get the weight value from the EditText
        String weightValueString = weightValueEditText.getText().toString();

        try {
            // Check if the input is not empty
            if (!weightValueString.isEmpty()) {
                // Convert the input to a double
                double weightValue = Double.parseDouble(weightValueString);

                // Get the current date as a string
                String date = getCurrentDateAsString();  // Add this line

                // Save the weight value to the database
                long result = weightDbHelper.addWeightEntry(weightValue, date);

            } else {
                // Display an error message if the input is empty
                Toast.makeText(this, "Please enter a weight value", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            // Handle the case where the conversion to double fails
            Toast.makeText(this, "Invalid weight value format", Toast.LENGTH_SHORT).show();
        }
    }

    private String getCurrentDateAsString() {
        // Here, we use the current date in the "yyyy-MM-dd" format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return dateFormat.format(new Date());
    }
}
